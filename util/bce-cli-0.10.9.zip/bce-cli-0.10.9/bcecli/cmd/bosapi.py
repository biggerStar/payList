# Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file
# except in compliance with the License. You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software distributed under the
# License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
# either express or implied. See the License for the specific language governing permissions
# and limitations under the License.
#coding=utf-8
"""
This module provides the major operations on BOS API.

Authors: BCE BOS
"""

# built-in
import json

# bce cli
from bcecli.baidubce.auth.bce_credentials import BceCredentials
from bcecli.baidubce.bce_client_configuration import BceClientConfiguration
from bcecli.baidubce.retry_policy import BackOffRetryPolicy
from bcecli.baidubce.services.bos.bos_client import BosClient
from bcecli.cmd import config
from bcecli.lazy_load_proxy import LazyLoadProxy
from bcecli.cmd import util

from bcecli.cmd.bos_init import bos


def put_lifecycle(args):
    """
    :param args: Parsed args, must have bucket_name
    """
    if args.template:
        lifecycle = {'rule': [{'id':'sample-id', 'resource':
            ['${bucket_name}/${prefix}/*'], 'action': {'name':'Transition',
                'storageClass':'STANDARD_IA'}, 'status':'enabled',
            'condition':{'time':{'dateGreaterThan':'$(lastModified)+P30D'}}}]}
        print(json.dumps(lifecycle, indent=2, separators=(',', ': ')))
        return
    if args.lifecycle_config_file is None or args.bucket_name is None:
        raise Exception('you must specify lifecycle_config_file and bucket_name')
    lifecycle = None
    with open(args.lifecycle_config_file) as data_file:
        lifecycle = json.load(data_file)
    print(json.dumps(lifecycle, indent=2, separators=(',', ': ')))
    bos.set_bucket_lifecycle(args.bucket_name, lifecycle)


def get_lifecycle(args):
    """
    :param args: Parsed args, must have bucket_name
    """
    lifecycle = bos.get_bucket_lifecycle(args.bucket_name)
    print(lifecycle.body)


def delete_lifecycle(args):
    """
    :param args: Parsed args, must have bucket_name
    """
    bos.delete_bucket_lifecycle(args.bucket_name)


def put_logging(args):
    """
    :param args: Parsed args, must have bucket_name
    """
    logging = {'status': 'enabled', \
            'targetBucket': args.target_bucket, \
            'targetPrefix': args.target_prefix}
    print(json.dumps(logging, indent=4, separators=(',', ': ')))
    bos.set_bucket_logging(args.bucket_name, logging)


def get_logging(args):
    """
    :param args: Parsed args, must have bucket_name
    """
    logging = bos.get_bucket_logging(args.bucket_name)
    logging = json.loads(logging.body)
    print(json.dumps(logging, indent=4, separators=(',', ': ')))


def delete_logging(args):
    """
    :param args: Parsed args, must have bucket_name
    """
    bos.delete_bucket_logging(args.bucket_name)


def put_bucket_storage_class(args):
    """
    :param args: Parsed args, must have bucket-name and storage-class
    """
    bucket_name = args.bucket_name
    storage_class = args.storage_class
    bos.put_bucket_storage_class(bucket_name, storage_class)


def get_bucket_storage_class(args):
    """
    :param args: Parsed args, must have bucket-name and storage-class
    """
    bucket_name = args.bucket_name
    storage_class = bos.get_bucket_storage_class(bucket_name)
    print(storage_class.body)
